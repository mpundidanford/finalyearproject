const express = require('express');
const router = express.Router();
const Department = require('../models/department')
const staffController = require('../controllers/staffs');
const { body } = require('express-validator');

router.get('/',  staffController.getIndex);
router.post('/leave', [
    
    
],  staffController.postLeave);


module.exports = router;
