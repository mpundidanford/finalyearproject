const express = require('express');
const bodyParser = require('body-parser')
const path = require('path');
const utilPath = require('./util/path');
const app = express();
const mongoose = require('mongoose');
const staffRouter = require('./routes/staff');
const RegisterRouter = require('./routes/register');
const flash = require('connect-flash');
const csurf = require('csurf');
const MongoDB_URI = 'mongodb://127.0.0.1:27017/testingpro';
const session = require('express-session');
const MongoDBStore = require('connect-mongodb-session')(session);
const multer = require('multer');
const store = new MongoDBStore({
  uri: MongoDB_URI,
  collection: 'sessions'
});
const csrfProtection = csurf();
const fileStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'documents');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + file.originalname);
  }
})
const fileFilter = (req, file, cb) => {
  if (file.mimetype === 'document/png' || file.mimetype === 'document/jpg' || file.mimetype === 'document/jpe' || file.mimetype === 'document/jpeg') {
    cb(null, true);
  } else {
    cb(null, false);
  }
}
app.set('view engine', 'ejs');
app.set('views', 'views');
app.use(bodyParser.urlencoded({
  extended: false
}));
app.use(multer({
  storage: fileStorage

}).single('document'));
app.use(express.static(path.join(utilPath, 'public')));
app.use('/documents', express.static(path.join(__dirname, 'documents')));
app.use(session({
  secret: 'my secret',
  resave: false,
  saveUninitialized: false,
  store: store
}))
app.use(csrfProtection);
app.use(flash());
app.use((req, res, next) => {
    res.locals.csrf = req.csrfToken()
  next();
})



app.use(staffRouter);
app.use(RegisterRouter);
mongoose.connect(MongoDB_URI,{useNewUrlParser:true,useUnifiedTopology:true},(err)=>{
  if(err){
    console.log('no db connection')
  }
  else{
    console.log('db has connected successfully')
  }
})
  
  .then(conn => {
    app.listen(4000,(err)=>{
      if(err){
        throw err;
      }
      console.log('Connected');
    });
   
  })
  .catch(err => {
    console.log(err);
  })