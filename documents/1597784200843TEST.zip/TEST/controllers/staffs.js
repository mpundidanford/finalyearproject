const Request = require("../models/request");
const moment = require('moment');
const path = require('path');
const fs = require('fs');

const PDFDocument = require('pdfkit');
const {
    validationResult
} = require('express-validator');
exports.getIndex = (req, res, next) => {
    Request.find({
            
        })
        .then(request => {
            res.render('users/index', {
                pagetitle: 'LAMS',
                page: '/',
                requests: request,
                errorMessage: null,
                validationCSS: [],
                oldValue: {
                   
                }
            })
        })
        .catch(err => {
            console.log(err);
        })
}
exports.postLeave = (req, res, next) => {
    const document = req.file.filename;

    const errors = validationResult(req);
    // console.log(duration,category,document)

    if (!document) {
        return res.status(422).render('admin/edit-product', {
            pagetitle: 'LAMS',
            page: '/',
            editing: false,
            errorMessage: 'Image needs to be a document..',
            validationCSS: errors.array(),
            oldValue: {
                
            }
        })
    }
    if (!errors.isEmpty()) {
        return res.status(422).render('users/index', {
            pagetitle: 'LAMS',
            page: '/',
            errorMessage: errors.array()[0].msg,
            validationCSS: errors.array(),
            oldValue: {
              
            }
        })
    }

    const request = new Request({
        attachment: document,
        date: moment().format('MMMM Do YYYY, h:mm:ss a')
    });
    request.save()
        .then(() => {
            return res.redirect('/');
        })
        .catch(err => {
            console.log(err);
        })
}
